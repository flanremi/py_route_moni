import os

for i in range(2,4):
    os.system("python draw.py " + str(i))
